import socket
c = socket.socket()
c.connect(('127.0.0.1', 1234))
c.send(b'hello world')
print(c.recv(1024).decode())
c.close()