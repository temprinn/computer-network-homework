import socket
s = socket.socket()
s.bind(('127.0.0.1', 1234))
s.listen(1)
conn, _ = s.accept()
data = conn.recv(1024)
conn.send(data.upper())
conn.close()
s.close()
